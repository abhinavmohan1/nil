from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Notification(models.Model):
    NOTIFICATION_TYPES = (
        ('MESSAGE', 'New Message'),
        ('ABSENCE', 'Student Absence'),
        ('TRAINER_ABSENT', 'Trainer Absent'),
        ('COURSE_ENDING', 'Course Ending'),
    )

    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.notification_type} for {self.recipient.username}"